<?php
require_once('v_head2.php');
require_once('v_header.php');
require_once('v_nav.php');
require_once('v_content.php');
require_once('v_footer2.php');
